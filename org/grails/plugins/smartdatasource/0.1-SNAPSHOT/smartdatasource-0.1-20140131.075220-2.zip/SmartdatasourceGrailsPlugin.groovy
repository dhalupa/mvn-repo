import org.grails.plugins.smartdatasource.DataSourceArtefactHandler;

class SmartdatasourceGrailsPlugin {
    // the plugin version
    def version = "0.1-SNAPSHOT"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.3.7 > *"
    // the other plugins this plugin depends on
    def dependsOn = [:]
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp",
            "grails-app/domain/**"
    ]

    def title = "Smartdatasource Plugin" // Headline display name of the plugin
    def author = "Denis Halupa"
    def authorEmail = "denis.halupa@gmail.com"
    def description = '''\
This is the plugin which supports operation of smartclient datasources
'''

    def artefacts = [
            DataSourceArtefactHandler
    ]
    // watch for any changes in these directories
    def watchedResources = [
            "file:./grails-app/dataSources/**/*DataSource.groovy",
            "file:../../plugins/*/dataSources/**/*DataSource.groovy"
    ]

    // Grails calls this when one of the files matching 'watchedResources' changes.
    // We have to actually swap in the new class when the source changes
    // There isn't anything special here, it's just boilerplate.
    def onChange = { event ->
        application.mainContext.dataSourceDefinitionService.resetDefinitions()
        if (application.isArtefactOfType(DataSourceArtefactHandler.TYPE, event.source)) {
            def oldClass = application.getDataSourceClass(event.source.name)
            application.addArtefact(DataSourceArtefactHandler.TYPE, event.source)

            // Reload subclasses
            application.dataSourceClasses.each {
                if (it.clazz != event.source && oldClass.clazz.isAssignableFrom(it.clazz)) {
                    def newClass = application.classLoader.reloadClass(it.clazz.name)
                    application.addArtefact(DataSourceArtefactHandler.TYPE, newClass)
                }
            }
        }
    }
    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/smartdatasource"

    def doWithSpring = {

        application.dataSourceClasses.each { dataSourceClass ->
            "${dataSourceClass.fullName}"(dataSourceClass.clazz) { bean ->
                bean.autowire = "byName"
            }
        }
    }


}
