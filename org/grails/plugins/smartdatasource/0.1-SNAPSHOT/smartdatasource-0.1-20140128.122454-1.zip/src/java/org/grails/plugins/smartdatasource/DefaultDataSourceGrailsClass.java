package org.grails.plugins.smartdatasource;

import org.codehaus.groovy.grails.commons.AbstractInjectableGrailsClass;

public class DefaultDataSourceGrailsClass extends AbstractInjectableGrailsClass implements DataSourceGrailsClass {

	public DefaultDataSourceGrailsClass(Class<?> clazz) {
		super(clazz, DataSourceArtefactHandler.TYPE);
	}
}
