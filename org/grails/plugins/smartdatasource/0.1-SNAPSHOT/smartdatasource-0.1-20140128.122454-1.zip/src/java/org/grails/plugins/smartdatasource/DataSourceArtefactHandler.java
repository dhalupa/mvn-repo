package org.grails.plugins.smartdatasource;

import org.codehaus.groovy.grails.commons.ArtefactHandlerAdapter;

public class DataSourceArtefactHandler extends ArtefactHandlerAdapter {
	

	public static final String TYPE = "DataSource";

	public DataSourceArtefactHandler() {
		super(TYPE, DataSourceGrailsClass.class, DefaultDataSourceGrailsClass.class, TYPE);
	}

}
