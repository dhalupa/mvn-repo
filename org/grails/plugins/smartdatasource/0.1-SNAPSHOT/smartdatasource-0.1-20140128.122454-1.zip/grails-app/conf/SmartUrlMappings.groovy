class SmartUrlMappings {

	static mappings = {
		"/datasource"(controller:"datasource",action:"serve")
		
		
		
	}
}
