package org.grails.plugins.smartdatasource

import org.grails.plugins.smartdatasource.builder.FieldsDefinitionBuilder
import org.springframework.transaction.support.TransactionCallback
import org.springframework.transaction.support.TransactionTemplate

import java.text.DateFormat;
import java.text.SimpleDateFormat

import org.codehaus.groovy.grails.commons.GrailsClassUtils;
import org.codehaus.groovy.grails.web.converters.configuration.ConverterConfiguration;
import org.codehaus.groovy.grails.web.converters.configuration.ConvertersConfigurationHolder
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.propertyeditors.CustomDateEditor;

import grails.converters.JSON

class DatasourceController {

    static final String DOMAIN_CLASS = 'domainClass'
    static jsonPrefix = "<SCRIPT>//'\"]]>>isc_JSONResponseStart>>"
    static jsonSuffix = "//isc_JSONResponseEnd"
    static final String JSON_DATE_FORMAT = "yyyy-MM-dd'T'hh:mm:ss'Z'";

    def messageSource
    def grailsApplication
    def sessionFactory
    def transactionManager
    def dataSourceDefinitionService


    def index = { serve() }


    def serve() {
        def transaction = request.JSON.transaction
        def model
        if (transaction) {
            model = []
            transaction.operations.each { operation ->
                def resp = generateOperationsResponse(operation)
                resp.response.queueStatus = 0
                model << resp
            }
            JSON.use('smart', {
                render jsonPrefix + (model as JSON) + jsonSuffix
            })
        } else {
            def json = request.JSON
            def dataSourceClass = grailsApplication.getArtefactByLogicalPropertyName(DataSourceArtefactHandler.TYPE, json.dataSource)
            def marshalingConfig = GrailsClassUtils.getStaticPropertyValue(dataSourceClass.clazz, 'marshalingConfig') ?: 'smart'
            model = generateOperationsResponse(json)
            JSON.use(marshalingConfig, {
                render jsonPrefix + (model as JSON) + jsonSuffix
            })
        }

    }

    private generateOperationsResponse(operation) {
        def retValue
        def operationType = operation.operationType
        def dataSourceName = operation.dataSource
        def dataSourceClass = grailsApplication.getArtefactByLogicalPropertyName(DataSourceArtefactHandler.TYPE, dataSourceName)
        def dataSource = grailsApplication.mainContext.getBean("${dataSourceClass.fullName}")
        if (operationType == 'custom') {
            if (dataSource.metaClass.respondsTo(dataSource, operation.operationId, Map)) {
                retValue = new TransactionTemplate(transactionManager).execute({ status ->
                    def ret
                    try {
                        ret = dataSource.invokeMethod(operation.operationId, operation.data)
                        sessionFactory.currentSession.flush()
                        return ret
                    } catch (Throwable t) {
                        log.error(t.message, t)
                        status.setRollbackOnly()

                    }
                    return ret
                } as TransactionCallback)
                retValue = ['response': [status: 0, data: [retValue: retValue]]]
            } else {
                def msg = "custom handler '${dataSourceName}.${operation.operationId}' not found!"
                log.error(msg)
                return ['response': [status: -1, data: msg]]
            }

        } else {
            def handler = this[operationType]
            retValue = new TransactionTemplate(transactionManager).execute({ status ->
                def ret
                try {
                    ret = handler.call(dataSource, operation)
                    sessionFactory.currentSession.flush()
                    return ret
                } catch (Throwable t) {
                    log.error(t.message, t)
                    status.setRollbackOnly()
                    ret = ['response': [status: -1, data: t.message]]
                }
                return ret
            } as TransactionCallback)


        }
        retValue
    }


    private fetch = { dataSource, input ->
        def model = dataSource.fetch(input)
        return ['response': [
                status: 0,
                startRow: 0,
                endRow: model.size(),
                totalRows: model.size(),
                data: model
        ]
        ]
    }


    private update = { dataSource, input ->
        def value
        if (dataSource.metaClass.respondsTo(dataSource, 'update', Map, Map)) {
            def changedValues = fetchChangedValues(input)
            value = dataSource.update(input.data, changedValues)
        } else {
            def domainClass = GrailsClassUtils.getStaticPropertyValue(dataSource.class, DOMAIN_CLASS)
            value = domainClass.get(input.data.id)
            value = updateValueInternal(value, input, dataSource)
            value.save()
        }
        renderDataUpdateResponse(value)
    }

    private add = { dataSource, input ->
        def value
        if (dataSource.metaClass.respondsTo(dataSource, 'add', Map)) {
            def changedValues = fetchChangedValues(input)
            value = dataSource.add(input.data)
        } else {
            def domainClass = GrailsClassUtils.getStaticPropertyValue(dataSource.class, DOMAIN_CLASS)
            value = domainClass.newInstance()
            value = updateValueInternal(value, input, dataSource)
            value.save()
        }
        return renderDataUpdateResponse(value)
    }

    private remove = { dataSource, input ->
        def domainClass = GrailsClassUtils.getStaticPropertyValue(dataSource.class, DOMAIN_CLASS)
        def value
        if (dataSource.metaClass.respondsTo(dataSource, 'remove', Map)) {
            value = dataSource.remove(input.data)
        } else {
            value = domainClass.get(input.data.id)
            value = value.delete()
        }
        return renderDataResponse(value)
    }

    private def renderDataUpdateResponse(value) {
        if (value.response) {
            return value;
        } else if (value.errors?.hasErrors()) {
            def d = ['response': [status: -4]]
            def errors = [:]
            value.errors.allErrors.each { err ->
                if (!errors[err.field]) {
                    errors[err.field] = [
                            [errorMessage: messageSource.getMessage(err, null)]
                    ]
                } else {
                    errors[err.field] << [errorMessage: messageSource.getMessage(err, null)]
                }
            }
            d.response.errors = errors
            return d
        } else {
            return renderDataResponse(value)
        }
    }


    private def renderDataResponse(value) {
        return ['response': [status: 0, data: value]]
    }


    private def updateValueInternal(value, input, dataSource) {
        BeanWrapperImpl wrapper = new BeanWrapperImpl(value)
        DateFormat dateFormat = new SimpleDateFormat(JSON_DATE_FORMAT);
        wrapper.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
        def converters = GrailsClassUtils.getStaticPropertyValue(dataSource.class, 'converters') ?: [:]
        def persistors = GrailsClassUtils.getStaticPropertyValue(dataSource.class, 'persistors') ?: [:]
        def changedValues = fetchChangedValues(input)
        changedValues.each { propertyName, propertyValues ->
            if (wrapper.isWritableProperty(propertyName)) {
                if (converters[propertyName]) {
                    wrapper.setPropertyValue(propertyName, converters[propertyName].call(propertyValues.newValue))
                } else if (persistors[propertyName]) {
                    persistors[propertyName].call(value, propertyValues)
                } else {
                    wrapper.setPropertyValue(propertyName, propertyValues.newValue)
                }
            }
        }
        return value
    }

    private def fetchChangedValues(input) {
        def model = [:]
        input.data.each { key, value ->
            if (value != input.oldValues[key]) {
                model[key] = [newValue: value, oldValue: input.oldValues[key]]
            }
        }
        return model
    }

    def definitions() {
        render(text: dataSourceDefinitionService.definitions, contentType: 'application/javascript')
    }


}
